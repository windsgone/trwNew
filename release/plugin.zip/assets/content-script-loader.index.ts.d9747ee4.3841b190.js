(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.ts.d9747ee4.js")
    );
  })().catch(console.error);

})();
